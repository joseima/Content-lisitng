Web developer challenge 

IMDB provides a way to download tab-separated files with movie listings. We would like you to create a webpage (a single page or not) that will list the movies from the downloaded files with the following requirements. We limit the challenge to movies only. 

1) For each movie, the listing shows its:

 - title

 - category/genre

 - year

 - rating

 - runtime (how long it is)

 - a small icon of the poster

 - a link to the IMDB page of that movie

 

2) we can order/sort by:

 - runtime

 - year

 - rating

 - and of course, by title

 

3) we can filter by:

 - category/genre

 - by runtime

 - and of course, by title

In consequence, the webpage can list movies, and it can also help search for an Action movie no longer than 2 hours with a rating greater than 8.5. This is just an example. 

IMBD and movies might look like a silly example, but, with distance, you'll see that it reflects rather closely the type of functionality we will use: display some information from a data store and give the user the possibility to further filter out this information for a given query.

The data files can be downloaded from https://datasets.imdbws.com/. Their description is here: https://www.imdb.com/interfaces/. Pick the relevant ones.

We are aware that you might not have a lot of time for it, and that's actually a parameter of the challenge: We are interested in  how you tackle the challenge and how far you go. We know that given all the time in the world, everyone would make the perfect page.

For the challenge,

* Use the technology you prefer,

* do reorganize the data, as you see fit,

* inspire yourself from " https://www.imdb.com/search/title/?groups=top_1000&view=simple&sort=user_rating,desc"

* update the requirements if you find a better solution (display, filter, sorting...)

Furthermore, you can use a Linux virtual machine running inside Virtual Box, for example, or a docker container, as you prefer.