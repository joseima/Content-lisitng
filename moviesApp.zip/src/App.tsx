
import { useRoutes, BrowserRouter } from 'react-router-dom'
import { Home } from './views/Home'
import { Navbar } from './components/NavBar'
import { ThisChallenge } from './views/ThisChallenge'
import { NotFound } from './views/NotFound'

const AppRouter = () => {


  const routes = useRoutes([
    { path: '/', element: <Home /> },
    { path: '/this_challenge', element: <ThisChallenge />},
    { path: '/*', element: <NotFound />}
  ])
  return routes
}


export const App = () : JSX.Element  => {

  return (
        <main>
          <BrowserRouter>
            <Navbar/>
            <AppRouter/>
        </BrowserRouter>
      </main>
  )
}
