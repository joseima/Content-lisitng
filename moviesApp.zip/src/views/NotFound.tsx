export const NotFound = () => {
    return (
      <main>
         We&lsquo;re loosing you!!
      </main>
    )
  }
  